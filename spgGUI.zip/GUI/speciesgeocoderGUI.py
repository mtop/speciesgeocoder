#!/usr/bin/env python 
# Created by Daniele Silvestro on 13/06/2011. => dsilvestro@senckenberg.de 
import sys
import os 
import os.path
print """
Welcome to SpeciesGeoCoder GUI! 

This is the console were infos, warning and error messages may appear...

"""
from speciesgeocoder import main
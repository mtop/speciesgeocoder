ADD ALL Speciesgeoceoder files inside the directory speciesgeocoder/spgeocod_lib/ 

To start the GUI type 

python speciesgeocoderGUI.py

or 

./speciesgeocoderGUI.py

On Windows you can double-click on speciesgeocoderGUI.py


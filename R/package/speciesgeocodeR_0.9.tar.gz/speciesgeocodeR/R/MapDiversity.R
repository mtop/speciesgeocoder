MapDiversity <-
function(x, scale = "CUSTOM", leg = "continuous", lim = "polygons", show.occ = F){
  if (!class(x) ==  "spgeoOUT"){
    stop("This function is only defined for class spgeoOUT")
  }
  
  num <- data.frame(poly = colnames(x$polygon_table),
                    spec.num = t(x$polygon_table),  
                    row.names = NULL, stringsAsFactors = F)
  num$poly <- gsub("."," ", num$poly, fixed = T)
  num$poly <- gsub("  "," ", num$poly, fixed = T)
  
  if(scale == "CUSTOM" ){
    if(class(x$polygons) == "SpatialPolygonsDataFrame" && "ECO_NAME" %in% names(x$polygons)){
      scale <- "ECOREGION"
    }else{
      x$polygons <- SpatialPolygonsDataFrame(x$polygons,data.frame(names(x$polygons), row.names = names(x$polygons)))
      names(x$polygons) <- c("ECO_NAME")
      nam <- data.frame(ECO_NAME = x$polygons$ECO_NAME)
    
      polys.df <- merge(nam, num, sort = F, by.x = "ECO_NAME", by.y = "poly", all = T)
    }    
  }
  if(scale == "REALM")
  {
    indrealm <- data.frame(string = c("Australasia", "Antarctic", 
                        "Afrotropics", "IndoMalay", 
                        "Nearctic", "Neotropics", 
                        "Oceania", "Palearctic"), 
                      REALM.ID = c("AA", "AN", "AT", "IM", "NA", "NT", "OC", "PA"))
    
    num <- merge(num,indrealm, by.x = "poly", by.y = "string")
    num <- num[,c(2,3)]
    
    nam <- data.frame(ECO_NAME = x$polygons$ECO_NAME,REALM_NAME = x$polygons$REALM)#diffrent
    
    
    polys.df <- merge(nam, num, sort = F, by.x = "REALM_NAME", by.y = "REALM.ID", all = T)
  }
  
  if(scale == "BIOME")
  {
    indbiom <- data.frame(string = c( "Tropical and Subtropical Moist Broadleaf Forests", 
                                      "Tropical and Subtropical Dry Broadleaf Forests", 
                                      "Tropical and Subtropical Coniferous Forests", 
                                      "Temperate Broadleaf and Mixed Forests", 
                                      "Temperate Conifer Forests", 
                                      "Boreal Forests/Taiga", 
                                      "Tropical and Subtropical Grasslands and Savannas and Shrublands", 
                                      "Temperate Grasslands and Savannas and Shrublands", 
                                      "Flooded Grasslands and Savannas", 
                                      "Montane Grasslands and Shrublands", 
                                      "Tundra", 
                                      "Mediterranean Forests Woodlands and Scrub", 
                                      "Deserts and Xeric Shrublands", 
                                      "Mangroves"), BIOME.ID = c(1:14))
    
    num <- merge(num,indbiom, by.x = "poly", by.y = "string")
    num <- num[,c(2,3)]
    
    nam <- data.frame(ECO_NAME = x$polygons$ECO_NAME,BIOME_NAME = x$polygons$BIOME)#diffrent

    
    polys.df <- merge(nam, num, sort = F, by.x = "BIOME_NAME", by.y = "BIOME.ID", all = T) #
  }
  if(scale == "ECOREGION"){
    nam <- data.frame(ECO_NAME = x$polygons$ECO_NAME) 
    nam$ECO_NAME <- gsub("-"," ", nam$ECO_NAME, fixed = T)
    polys.df <- merge(nam, num, sort = F, by.x = "ECO_NAME", by.y = "poly", all = T)
  }
  
  polys.df$spec.num[is.na(polys.df$spec.num)] <- 0
  
  if(leg == "continuous"){
    colo <- data.frame(num = c(0:max(polys.df$spec.num)),
                       code = c("#FFFFFFFF", rev(heat.colors(max(polys.df$spec.num))))) 
    
  }else{
    colo <- data.frame(num = c(0,sort(unique(polys.df$spec.num))),
                       code = c("#FFFFFFFF", rev(rainbow(length(unique(polys.df$spec.num))))))
    if(colo$num[2] == 0){colo <- colo[-2,]}
  }
  
  polys.df <- merge(polys.df, colo, sort = F, by.x = "spec.num", by.y = "num", all = F)
  
  polys.df$ord <- pmatch(polys.df$ECO_NAME,nam$ECO_NAME)
  polys.df <- polys.df[order(polys.df$ord),]
  
  sp.count <-  polys.df$spec.num
  poly.col <- polys.df$code
  
  plotpoly <- spCbind(x$polygons, sp.count)
  plotpoly <- spCbind(plotpoly, poly.col)
  
  if(lim == "polygons"){
    limits <- bbox(plotpoly)
    if(limits[1,1] < -170 && limits[1,2] > 170 && max(x$species_coordinates$XCOOR) < -10){limits[1,2] <- -10}
    if(limits[1,1] < -170 && limits[1,2] > 170 && min(x$species_coordinates$XCOOR) > 0){limits[1,1] <- 0}
    limits[1,1] <-  max(limits[1,1] - abs(abs(limits[1,1])- abs(limits[1,2])) * .2, -180)
    limits[1,2] <-  min(limits[1,2] + abs(abs(limits[1,1])- abs(limits[1,2])) * .2, 180)
    limits[2,1] <-  max(limits[2,1] - abs(abs(limits[2,1])- abs(limits[2,2])) * .2, -90)
    limits[2,2] <-  min(limits[2,2] + abs(abs(limits[2,1])- abs(limits[2,2])) * .2, 90)
  }
  if(lim == "points"){
    limits <- matrix(ncol = 2, nrow = 2)
    limits[1,1] <-  max(min(x$species_coordinates_in$XCOOR) - 
                          abs(min(x$species_coordinates_in$XCOOR)- 
                                max(x$species_coordinates_in$XCOOR)) * .2, -180)
    limits[1,2] <-  min(max(x$species_coordinates_in$XCOOR) +
                          abs(abs(min(x$species_coordinates_in$XCOOR))- 
                                abs(max(x$species_coordinates_in$XCOOR))) * .2, 180)
    limits[2,1] <-  max(min(x$species_coordinates_in$YCOOR) - 
                          abs(min(x$species_coordinates_in$YCOOR)- 
                                max(x$species_coordinates_in$YCOOR)) * .2, -90)
    limits[2,2] <-  min(max(x$species_coordinates_in$YCOOR) +
                          abs(abs(min(x$species_coordinates_in$YCOOR))- 
                                abs(max(x$species_coordinates_in$YCOOR))) * .2, 90)
  }
  
  if(scale == "BIOME" | scale == "REALM") 
    {
    lin.col <- as.character(plotpoly$poly.col)
  }else{
    lin.col <- rgb(153,153,153, maxColorValue = 255, alpha = 255)
    } 
  if(length(unique(plotpoly$sp.count)) == 1){leg <- "discrete"}
  layout(matrix(c(1, 1, 1, 1, 1,  2), ncol =  6, nrow = 1))
  map("world", xlim = limits[1,], ylim = limits[2,])
  axis(1)
  axis(2)
  plot(plotpoly, col = as.character(plotpoly$poly.col), border = lin.col, add = T)
  if(show.occ == T){
  points(x$species_coordinates_in$XCOOR,x$species_coordinates_in$YCOOR)
  }
  box("plot")
  if(leg == "continuous"){
    par(mar = c(5,1,5,3))
        ifelse(max(plotpoly$sp.count) < 25, leng <- max(plotpoly$sp.count),leng <- 11)
    ticks <- round(seq(min(plotpoly$sp.count), max(plotpoly$sp.count), len = leng),0)
    scale <- (length(colo$num) - 1) / (max(plotpoly$sp.count) - min(plotpoly$sp.count))
    plot(c(0,10), c(min(plotpoly$sp.count),max(plotpoly$sp.count)), 
         type='n', bty='n', xaxt='n', xlab='', yaxt='n', ylab='')
    axis(4, ticks, las=1)
    for (i in 1:(length(colo$num))) {
      y = (i - 1)/scale + min(plotpoly$sp.count)
      rect(0, y, 10, y + 1 / scale, col= as.character(colo$code[i]), border=NA)
    }
    box("plot")
  }
  if(leg == "discrete"){
    par(mar = c(5,1,5,3))
    plot(c(0,10), c(min(colo$num),dim(colo)[1]+1), 
         type='n', bty='n', xaxt='n', xlab='', yaxt='n', ylab='', xpd = F)
    
    if(length(unique(plotpoly$sp.count)) == 1)
    {
      rect(0, (dim(colo)[1]+1)/2 -3 , 5, (dim(colo)[1]+1)/2 -1,  col= "white", border = "black")
      rect(0, (dim(colo)[1]+1)/2 +1 , 5, (dim(colo)[1]+1)/2 +3,  
           col= as.character(colo$code[unique(plotpoly$sp.count)]), border = NA)
      text(7, (dim(colo)[1]+1)/2 -2 , labels = "0")
      text(7, (dim(colo)[1]+1)/2 +2, labels = unique(plotpoly$sp.count))
    }else{    
      scale <- (length(colo$num) - 1) / (length(colo$num) - min(plotpoly$sp.count))
      for (i in 1:length(colo$num)) 
        {
        y = (i - 1)/scale + min(plotpoly$sp.count)
        rect(0, y, 5, y + 1 / scale, col= as.character(colo$code[i]), border=NA)
        text(8,y + 1 / scale / 2, colo$num[i])
        }
      rect(0,min(plotpoly$sp.count),5,length(colo$num)+ 1 / scale)
    }
  }
}

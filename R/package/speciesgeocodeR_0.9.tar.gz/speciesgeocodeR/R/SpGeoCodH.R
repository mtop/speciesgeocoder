SpGeoCodH <-
function(x){
  if (class(x) ==  "spgeoIN"){
    kkk <- .PipSamp(x)
    spsum <- .SpSumH(kkk)
    
    if(length(spsum) == 0)
      {
      namco <- c("identifier", names(x$polygons))
      fill <- matrix(0, nrow = length(unique(kkk$identifier)), ncol = length(names(x$polygons)))
      fill <- data.frame(fill)
      spsum <- data.frame(cbind(as.character(unique(kkk$identifier)),fill))
      names(spsum) <- namco   
      }
    
    sppol <- .SpPerPolH(spsum)
    
    
    nc <- subset(kkk, is.na(kkk$homepolygon))
    identifier <- x$identifier[as.numeric(rownames(nc))]
    bb <- x$species_coordinates[as.numeric(rownames(nc)), ]
    miss <- data.frame(identifier, bb)
    names(miss) <- c("identifier","XCOOR","YCOOR")
    
    out <- list(identifier_in = x$identifier, species_coordinates_in = x$species_coordinates, polygons = x$polygons, 
                sample_table = kkk, spec_table = spsum, polygon_table = sppol, 
                not_classified_samples = miss, coexistence_classified = "NA")
    class(out) <- "spgeoOUT"
    return(out)    
  }else{
    stop("Function is only defined for class spgeoIN")  
  }
}

MapGrid <-
function(rast){
  #   colo <- rev(heat.colors(length(getValues(rast))))
  plot(rast) #, col = colo)
  map("world", add = T)
  
}

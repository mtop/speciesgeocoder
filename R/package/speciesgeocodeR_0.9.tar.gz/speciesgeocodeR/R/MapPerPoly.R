MapPerPoly <-
function(x, scale, plotout = FALSE){
  if (!class(x) ==  "spgeoOUT"){
    stop("This function is only defined for class spgeoOUT")
  }
  dum <- x$polygons
  if(class(dum) == "SpatialPolygonsDataFrame")
    {
     if(scale == "ECOREGION"){liste1 <- liste2 <- unique(dum$ECO_NAME)}
     if(scale == "BIOME")
     {
       liste1  <- liste2 <- unique(dum$BIOME)
       indbiome <- cbind(c( "Tropical and Subtropical Moist Broadleaf Forests", 
                            "Tropical and Subtropical Dry Broadleaf Forests", 
                            "Tropical and Subtropical Coniferous Forests", 
                            "Temperate Broadleaf and Mixed Forests", 
                            "Temperate Conifer Forests", 
                            "Boreal Forests/Taiga", 
                            "Tropical and Subtropical Grasslands and Savannas and Shrublands", 
                            "Temperate Grasslands and Savannas and Shrublands", 
                            "Flooded Grasslands and Savannas", 
                            "Montane Grasslands and Shrublands", 
                            "Tundra", 
                            "Mediterranean Forests, Woodlands and Scrub", 
                            "Deserts and Xeric Shrublands", 
                            "Mangroves"), c(1:14))
       for(i in 1: dim(indbiome)[1])
       {
         liste1[liste1 == indbiome[i,2]] <- indbiome[i,1]
       }
     }
     if(scale == "REALM")
     {
       liste1  <- liste2 <- as.character(unique(dum$REALM))
       indrealm <- cbind(c("Australasia", "Antarctic", 
                           "Afrotropics", "IndoMalay", 
                           "Nearctic", "Neotropics", 
                           "Oceania", "Palearctic"), 
                         c("AA", "AN", "AT", "IM", "NA", "NT", "OC", "PA"))
       for(i in 1: dim(indrealm)[1])
       {
         liste1[liste1 == indrealm[i,2]] <- indrealm[i,1]
       }
     }   
     len <- length(liste1)
  }else{
    len <- length(names(dum))
  }
    for(i in 1:len){
      if(class(dum) == "SpatialPolygonsDataFrame"){
        cat(paste("Creating map for polygon ", i,"/",length(liste1), ": ", liste1[i], "\n",sep = ""))
        chopo <- liste1[i]
        if(scale == "ECOREGION")
        {
          xmax <- min(max(bbox(subset(dum,dum$ECO_NAME == liste1[i]))[1, 2]) + 5, 180)
          xmin <- max(min(bbox(subset(dum,dum$ECO_NAME == liste1[i]))[1, 1]) - 5, -180)
          ymax <- min(max(bbox(subset(dum,dum$ECO_NAME == liste1[i]))[2, 2]) + 5, 90)
          ymin <- max(min(bbox(subset(dum,dum$ECO_NAME == liste1[i]))[2, 1]) - 5, -90)
        }
        if(scale == "BIOME")
        {
          xmax <- min(max(bbox(subset(dum,dum$BIOME == liste2[i]))[1, 2]) + 5, 180)
          xmin <- max(min(bbox(subset(dum,dum$BIOME == liste2[i]))[1, 1]) - 5, -180)
          ymax <- min(max(bbox(subset(dum,dum$BIOME == liste2[i]))[2, 2]) + 5, 90)
          ymin <- max(min(bbox(subset(dum,dum$BIOME == liste2[i]))[2, 1]) - 5, -90)
        }
        if(scale == "REALM")
        {
          xmax <- min(max(bbox(subset(dum,dum$REALM == liste2[i]))[1, 2]) + 5, 180)
          xmin <- max(min(bbox(subset(dum,dum$REALM == liste2[i]))[1, 1]) - 5, -180)
          ymax <- min(max(bbox(subset(dum,dum$REALM == liste2[i]))[2, 2]) + 5, 90)
          ymin <- max(min(bbox(subset(dum,dum$REALM == liste2[i]))[2, 1]) - 5, -90)
        }
          
       }else{
        cat(paste("Creating map for polygon ", i,"/",length(names(dum)), ": ", names(dum)[i], "\n",sep = ""))
        chopo <- names(dum)[i]

        xmax <- min(max(bbox(x$polygons[i])[1, 2]) + 5, 180)
        xmin <- max(min(bbox(x$polygons[i])[1, 1]) - 5, -180)
        ymax <- min(max(bbox(x$polygons[i])[2, 2]) + 5, 90)
        ymin <- max(min(bbox(x$polygons[i])[2, 1]) - 5, -90)
       }
      
        
    po <- data.frame(x$sample_table, x$species_coordinates_in)
    subpo <- subset(po, as.character(po$homepolygon) ==  as.character(chopo))
    
    subpo <- subpo[order(subpo$identifier), ]  
    
    liste <- unique(subpo$identifier)
    leng <- length(liste)

    rain <- rainbow(leng)
    ypos <- vector(length = leng)
    yled <- (ymax - ymin) * 0.025
    for(k in 1:leng){
      ypos[k]<- ymax - yled * k
    }
    
    layout(matrix(c(1, 1, 1, 1,1, 2, 2), ncol =  7, nrow = 1))
    par(mar = c(3, 3, 3, 0))
    te <-try(map("world", xlim = c(xmin, xmax), ylim = c(ymin, ymax)), silent = T)
    if(class(te) == "try-error"){map("world")}
    axis(1)
    axis(2)
    box("plot")
    title(chopo)
    if(class(dum) == "SpatialPolygonsDataFrame")
      {
        if(scale == "ECOREGION"){plot(subset(dum,dum$ECO_NAME == liste1[i]), col = "grey60", add = T)}
        if(scale == "BIOME"){plot(subset(dum,dum$BIOME == liste2[i]), col = "grey60", add = T)}
        if(scale == "REALM"){plot(subset(dum,dum$REALM == liste2[i]), col = "grey60", add = T)}
      }else{
      plot(x$polygons[i], col = "grey60", add = T)
      }
    for(j in 1:leng){
      subsub <- subset(subpo,subpo$identifier == liste[j]) 
      points(subsub[,3], subsub[,4], 
             cex = 1, pch = 3 , col = rain[j])
      }
    #legend
    cat("Adding legend \n")
    par(mar = c(3, 0, 3, 0), ask = F)
    plot(c(1, 50), c(1, 50), type = "n", axes = F)
    if(leng == 0){
      yset <- 25
      xset <- 1}
    if (leng ==  1){
      yset <- 25
      xset <- rep(4, leng)
    }
    if(leng >  1){
      yset <- rev(sort(c(seq(25, 25 + max(ceiling(leng/2) - 1, 0)), 
                         seq(24, 24 - leng/2 + 1))))
      xset <- rep(4, leng)
    }
    points(xset-2, yset, pch =  3, col = rain)
    if(leng == 0){
      text(xset, yset, labels = "No species found in this polygon", adj = 0)
    }else{
      text(xset, yset, labels =  liste, adj = 0, xpd = T)
      rect(min(xset) - 4, min(yset) -1, 50 + 1, max(yset) + 1, xpd = T)
    }
    
    if (plotout ==  FALSE){par(ask = T)}
  }
  par(ask = F)
}

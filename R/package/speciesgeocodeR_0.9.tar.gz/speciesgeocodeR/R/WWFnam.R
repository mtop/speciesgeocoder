WWFnam <-
function(x) {
  indrealm <- cbind(c("Australasia", "Antarctic", 
                      "Afrotropics", "IndoMalay", 
                      "Nearctic", "Neotropics", 
                      "Oceania", "Palearctic"), 
                    c("AA", "AN", "AT", "IM", "NA", "NT", "OC", "PA"))
  rea <- indrealm[which(indrealm[, 2] %in% x$REALM), 1]
  
  indbiome <- cbind(c( "Tropical and Subtropical Moist Broadleaf Forests", 
                       "Tropical and Subtropical Dry Broadleaf Forests", 
                       "Tropical and Subtropical Coniferous Forests", 
                       "Temperate Broadleaf and Mixed Forests", 
                       "Temperate Conifer Forests", 
                       "Boreal Forests/Taiga", 
                       "Tropical and Subtropical Grasslands and Savannas and Shrublands", 
                       "Temperate Grasslands and Savannas and Shrublands", 
                       "Flooded Grasslands and Savannas", 
                       "Montane Grasslands and Shrublands", 
                       "Tundra", 
                       "Mediterranean Forests, Woodlands and Scrub", 
                       "Deserts and Xeric Shrublands", 
                       "Mangroves"), c(1:14))
  biom <- indbiome[which(indbiome[, 2] %in% x$BIOME), 1]
  
  ecoregion <- sort(unique(x$ECO_NAME))
  
  pp <- list(REALMS = rea, BIOMES = biom, ECOREGIONS = ecoregion)
  return(pp)
}

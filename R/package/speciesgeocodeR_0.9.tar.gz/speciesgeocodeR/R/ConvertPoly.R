ConvertPoly <-
function(x){
  x <- read.table(x,sep = "\t")

  out2 <- vector()
  
  for(j in 1:dim(x)[1]){
    aa <-as.character(x[j,])
    ff <- t(aa)
    bb <- unlist(strsplit(ff[1], split = ":"))
    bb <-c(bb[1], unlist(strsplit(bb[2], split = " ")))
    
    out <- vector()
    
    for(i in 3:length(bb)){
      dd <- c(bb[1], unlist(strsplit(as.character(bb[i]), split = ",")))
      out <- rbind(out, dd)
    }
    out2 <-rbind(out2,out)
  }
  
  colnames(out2) <- c("identifier", "XCOOR", "YCOOR")
  rownames(out2) <- NULL
  out2 <- as.data.frame(out2)
  return(out2)
}

WWFload <-
function(){
  download.file("http://assets.worldwildlife.org/publications/15/files/original/official_teow.zip",
  "wwf_ecoregions.zip")#?1349272619")
  unzip("wwf_ecoregions.zip", exdir = "WWF_ecoregions")
  file.remove("wwf_ecoregions.zip")
  if(Sys.info()['sysname'] == "Windows"){
    wwf <- readShapeSpatial("WWF_ecoregions\\official\\wwf_terr_ecos.shp")
  }else{
    wwf <- readShapeSpatial("WWF_ecoregions/official/wwf_terr_ecos.shp")
  }
  
  return(wwf)
}

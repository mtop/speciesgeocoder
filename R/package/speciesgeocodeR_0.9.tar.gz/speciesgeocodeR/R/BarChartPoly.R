BarChartPoly <-
function(x, plotout = F, ...){
  if (!class(x) ==  "spgeoOUT" && !class(x) ==  "spgeoH"){
    stop("This function is only defined for class spgeoOUT")
  }  
  if (plotout ==  FALSE){par(ask = T, mar = c(15, 4, 3, 3))}
  liste <- names(x$spec_table)
  leng <- length(liste)
  par(mar = c(15, 4, 3, 3))
  if(length(names(x$spec_table)) == 0){
    cat("No point fell in any polygon")
  }else{
    for(i in 2:leng){
      cat(paste("Creating barchart for polygon ", i-1, "/", leng, ": ", liste[i], "\n", sep = ""))
      subs <-subset(x$spec_table, x$spec_table[, i] > 0)
      datsubs <- subs[order(subs[, i]),]
      if(dim(subs)[1] == 0){
        plot(1:10,1:10,type = "n", xlab = "", ylab = "Number of occurences", )
        text(3,6, labels = "No species occurred in this polygon.", adj = 0)
        title(liste[i])
      }else{
       barplot(datsubs[, i], names.arg = datsubs$identifier, 
               las = 2, ylab = "Number of occurences",cex.names = .7)#, ...)
       title(liste[i])
      }
    }
  }
  par(ask = F)

}

PlotSpPoly <-
function(x, ...){
  if (class(x) ==  "spgeoOUT") {
    num <- length(names(x$polygon_table))
    dat <- sort(x$polygon_table)
    counter <- num/10
         if (length(x$polygon_table) != 0){
    par(mar = c(10, 4, 2, 2))
    barplot(as.matrix(dat[1,]), 
            ylim = c(0, round((max(dat) + max(dat)/4), 0)), 
            ylab = "Number of Species per Polygon", las = 2, ...)
    box("plot")
         }else{
    cat("No point in any polygon")  
           }
  }
  else{
    stop("This function is only defined for class <spgeoOUT>")
  }
}

BarChartSpec <-
function(x, mode = c("percent", "total"), plotout = FALSE, ...){
  match.arg(mode)
  if (!class(x) ==  "spgeoOUT" && !class(x) ==  "spgeoH"){
    stop("This function is only defined for class spgeoOUT")
  }
  if(length(x$spec_table) == 0){
    cat("No point was found inside the given polygons")
  }else{
    if (plotout ==  FALSE){par(ask = T)}
    if (mode[1] ==  "total"){
      liste <- x$spec_table$identifier
      leng <-  length(liste)
      par(mar = c(10, 4, 3, 3))
      for(i in 1:leng){
        cat(paste("Creating barchart for species ", i, "/", leng, ": ", liste[i], "\n", sep = ""))
        spsub <- as.matrix(subset(x$spec_table, x$spec_table$identifier ==  liste[i])[, 2:dim(x$spec_table)[2]])
        if (sum(spsub) > 0){
          barplot(spsub, las = 2, ylim = c(0, (max(spsub) + max(spsub) / 10)), 
                  ylab = "Number of occurrences", ...)
          title(liste[i])
        }
      }
    }
    if (mode[1] ==  "percent"){
      percent <- x$spec_table[, -1]
      anzpoly <-length(names(x$spec_table)[-1]) 
      if (anzpoly > 1){
        percent2  <- percent / rowSums(percent) * 100
      }else{
        percent2  <- percent / sum(percent) * 100
      }
      percent2[percent2 ==  "NaN"] <- 0
      percent2 <- data.frame(identifier = x$spec_table[, 1], percent2)
    
      liste <- x$spec_table$identifier
      leng <-  length(liste)
      leng2 <- length(colnames(percent2))
      par(mar = c(10, 4, 3, 3))
      for(i in 1:leng){
        cat(paste("Creating barchart for species ", i, "/", leng, ": ", liste[i], "\n", sep = ""))
        if (anzpoly > 1){
          spsub <- as.matrix(subset(percent2, percent2$identifier ==  liste[i])[, 2:leng2])
        }else{
          spsub <- as.matrix(percent2[percent2$identifier ==  liste[i], ][, 2:leng2])
          names(spsub) <- names(x$spec_table)[-1]
        }
        if (sum(spsub) > 0){
          barplot(spsub, las = 2, ylim = c(0, (max(spsub) + max(spsub) / 10)), 
                  ylab = "Percent of occurrences", names.arg = names(spsub), ...)
          title(liste[i])
        }
      }
    }  
    par(ask = F)
  }
}

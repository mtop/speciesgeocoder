NexusOut <-
function (x, verbose = FALSE){
  cat("Writing Nexus file \n")
  if(verbose == FALSE){
    sink("species_classification.nex")
  }
  if(verbose == TRUE){
    sink("species_classification_verbose.nex")
  }
  
  cat("#NEXUS \n")
  cat("\n")
  cat("Begin data; \n")
  cat(paste("\tDimensions ntax=",dim(x$spec_table)[1], 
            " nchar=", dim(x$spec_table)[2] - 1,";", sep = ""))
  cat("\n")
  cat("\tFormat datatype=standard symbols=\"01\" gap=-;")
  cat("\n")
  cat("\tCHARSTATELABELS")
  cat("\n")
  if(length(x$spec_table) == 0){
    cat("No point fell in any of the polygons specified")
    sink(NULL)
  }else{
  aa <- names(x$spec_table)[-1]
  bb <- seq(1,length(aa))
  
  cat(paste("\t", bb[-length(bb)], " ",aa[-length(aa)], ",\n", sep = ""))
  cat("\t", paste(bb[length(bb)], " ", aa[length(aa)], ";\n", sep = ""))
  cat("\n")
  cat("\tMatrix\n")
  
  dd <- as.matrix(x$spec_table[,-1])
  dd[dd > 0] <- 1
  
  if(dim(dd)[2] >1)
  {
  dd <- data.frame(dd)
  dd$x <- apply(dd[, names(dd)], 1, paste, collapse = "")
  }else{
    dd <- data.frame(dd,x = dd)
  }
  ff <- gsub(" ", "_",x$spec_table[,1])
  
  if(verbose == F)
  {
    ee <- paste(ff, "\t" ,dd$x, "\n",sep = "")
    cat(ee)
  }
  if(verbose == T){
    gg <- vector()
    jj <-x$spec_table[,-1]
    for( i in 1:dim(jj)[2])
    {
      hh <- paste(dd[,i],"[", jj[,i],"]", sep = "")
      gg <- data.frame(cbind(gg, hh))
    } 
    gg$x <- apply(gg[, names(gg)], 1, paste, collapse = "")
    ee <- paste(ff, "\t", gg$x, "\n", sep = "")
    cat(ee)
  }
  cat("\t;\n")
  cat("End;")
  sink(NULL)
  }
  cat("Done")
}

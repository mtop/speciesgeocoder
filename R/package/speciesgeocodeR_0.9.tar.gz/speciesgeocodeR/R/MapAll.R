MapAll <-
function(x, polyg, moreborders = F, ...){
  data("wrld_simpl", envir = environment())
  if (class(x) ==  "spgeoOUT"){
    xmax <- min(max(x$species_coordinates_in[, 1]) + 2, 180)
    xmin <- max(min(x$species_coordinates_in[, 1]) - 2, -180)
    ymax <- min(max(x$species_coordinates_in[, 2]) + 2, 90)
    ymin <- max(min(x$species_coordinates_in[, 2]) - 2, -90)
    difx <- sqrt(xmax^2 + xmin^2)
    dify <- sqrt(ymax^2 + ymin^2)  
    if(difx > 90){
      xmax <- min(xmax +10, 180)
      xmin <- max(xmin -10,-180)
      ymax <- min(ymax +10, 90)
      ymin <- max(ymin -10,-90)
    }
    cat("Creating map of all samples. \n")
    map ("world", xlim = c(xmin, xmax), ylim = c(ymin, ymax))
    axis(1)
    axis(2)
    box("plot")
    title("All samples")
    if (moreborders ==  T) {plot(wrld_simpl, add = T)}
    cat("Adding polygons. \n")
    plot(x$polygons, col = "grey60", border = "grey40", add = T, ...)
    cat("Adding sample points \n")
    points(x$species_coordinates_in[, 1], x$species_coordinates_in[, 2], 
           cex = 0.7, pch = 3 , col = "blue", ...)
  }
  if (class(x) ==  "matrix" || class(x) ==  "data.frame"){
    if (!is.numeric(x[, 1]) || !is.numeric(x[, 2])){
      stop(paste("Wrong input format:\n", 
                 "Point input must be a <matrix> or <data.frame> with 2 columns.\n", 
                 "Column order must be lon - lat.", sep = ""))
    }
    if (class(polyg) !=  "SpatialPolygons"){
      warning("To plot polygons, polyg must be of class <SpatialPolygons>.")
    }
    x <- as.data.frame(x)
    nums <- sapply(x, is.numeric)
    x<- x[, nums]
    xmax <- min(max(x[, 2]) + 2, 180)
    xmin <- max(min(x[, 2]) - 2, -180)
    ymax <- min(max(x[, 1]) + 2, 90)
    ymin <- max(min(x[, 1]) - 2, -90)
    if (ymax > 92 || ymin < -92){
      warning("Column order must be lon-lat, not lat - lon. Please check")
    }
    map ("world", xlim = c(xmin, xmax), ylim = c(ymin, ymax))
    axis(1)
    axis(2)
    title("All samples")
    box("plot")
    if (moreborders ==  T) {plot(wrld_simpl, add = T, ...)}
    if(class(polyg == "list"))

      plot(polyg, col = "grey60", add = T, ...)

    points(x[, 2], x[, 1], 
           cex = 0.5, pch = 3 , col = "blue", ...)
    
  }
}

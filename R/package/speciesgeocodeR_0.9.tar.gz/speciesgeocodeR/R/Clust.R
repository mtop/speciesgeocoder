Clust <-
function(x, shape, scale){
  cat(paste("Clustering information on", scale, "\n", sep = " "))
  if(scale != "ECOREGION"){
    nam <- unique(data.frame(as.character(shape$ECO_NAME),shape$BIOME,as.character(shape$REALM), stringsAsFactors = F))
    names(nam) <- c("ecoregion", "biome", "realm")
    
    indrealm <- cbind(c("Australasia", "Antarctic", 
                        "Afrotropics", "IndoMalay", 
                        "Nearctic", "Neotropics", 
                        "Oceania", "Palearctic"), 
                      c("AA", "AN", "AT", "IM", "NA", "NT", "OC", "PA"))
    
    indbiome <- cbind(c( "Tropical and Subtropical Moist Broadleaf Forests", 
                         "Tropical and Subtropical Dry Broadleaf Forests", 
                         "Tropical and Subtropical Coniferous Forests", 
                         "Temperate Broadleaf and Mixed Forests", 
                         "Temperate Conifer Forests", 
                         "Boreal Forests/Taiga", 
                         "Tropical and Subtropical Grasslands and Savannas and Shrublands", 
                         "Temperate Grasslands and Savannas and Shrublands", 
                         "Flooded Grasslands and Savannas", 
                         "Montane Grasslands and Shrublands", 
                         "Tundra", 
                         "Mediterranean Forests, Woodlands and Scrub", 
                         "Deserts and Xeric Shrublands", 
                         "Mangroves"), c(1:14))
    for(i in 1: dim(indbiome)[1])
    {
      nam$biome[nam$biome == indbiome[i,2]] <- indbiome[i,1]
    }
    for(i in 1: dim(indrealm)[1])
    {
      nam$realm[nam$realm == indrealm[i,2]] <- indrealm[i,1]
    }
    
    if(scale == "BIOME")
    {
      ppp <- as.character(x$sample_table$homepolygon)
      for(i in 1:length(nam$ecoregion))
      {
        ppp[ppp == nam$ecoregion[i]] <- nam$biome[i]
      }
    }
    if(scale == "REALM")
    {
      ppp <- as.character(x$sample_table$homepolygon)  
      for(i in 1:length(nam$ecoregion))
      {
        ppp[ppp == nam$ecoregion[i]] <- nam$realm[i]
      }
    }
    
    ppp <- as.factor(ppp)
    x$sample_table$homepolygon <-ppp
    
    x$spec_table <- .SpSumH(x$sample_table)
    
    
    if(length(x$spec_table) == 0)
    {
      namco <- c("identifier", names(x$polygons))
      fill <- matrix(0, nrow = length(unique(x$sample_table)), ncol = length(names(x$polygons)))
      fill <- data.frame(fill)
      x$spec_table <- data.frame(cbind(as.character(unique(x$sample_table$identifier)),fill))
      names(x$spec_table) <- namco   
    }       
    x$polygon_table <- .SpPerPolH(x$spec_table)      
  }
  cat("Done \n")
  return(x)
}

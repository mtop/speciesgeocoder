ReadPoints <-
function(x, y) {   
  res <- list()
  if(class(x) != "character" && class(x) != "data.frame"){
    stop(paste("Function not defined for class: ", class(x), sep = ""))
  }
  if(class(x) == "character"){  
    coords <- read.table(x, sep = "\t", header = T)
  }
  if(class(x) == "data.frame"){
    coords <- x
  }
    
  if(class(y) != "SpatialPolygonsDataFrame" && class(y) != "SpatialPolygons")
  {
    cat("Reading in polygon coordinates. \n")
    if(class(y) == "character"){
      polycord <- read.table(y, sep = "\t", header = T)
    }
    if(class(y) == "data.frame"){
      polycord <- y
    }
    if (dim(polycord)[2] !=  3){
      stop(paste("Wrong input format: \n", 
                 "Inputfile for polygons must be a tab-delimited text file with three columns", sep  = ""))
    }
    if (!is.numeric(polycord[, 2]) || !is.numeric(polycord[, 3])){
      stop(paste("Wrong input format: \n", 
                 "Input polygon coordinates (columns 2 and 3) must be numeric.", sep  = ""))
    }
    if (!is.character(polycord[, 1]) && !is.factor(polycord[, 1])){
      warning("Polygon identifier (column 1) should be a string or a factor.")
    }
    if(max(polycord[, 2]) > 180){
      warning(paste("Check polygon input coordinates. File contains longitude values outside possible range in row:",
                 rownames(polycord[polycord[,2] > 180,]),"\n", "Coordinates set to maximum: 180 \n", sep = ""))
      polycord[polycord[, 2] > 180,2] <- 180
    }
    if(min(polycord[, 2]) < -180){
      warning(paste("Check polygon input coordinates. File contains longitude values outside possible range in row: ",
                    rownames(polycord[polycord[,2] < -180,]),"\n", "Coordinates set to minimum: -180 \n", sep = ""))
      polycord[polycord[, 2] < -180,] <- -180

    }
    if(max(polycord[, 3]) > 90){
      warning(paste("Check polygon input coordinates. File contains latitude values outside possible range in row:",
                 rownames(polycord[polycord[,3] > 90,]),"\n", "Coordinates set to maximum: 90 \n", sep = ""))
      polycord[polycord[, 3] > 90,3] <- 90
    }
    if(min(polycord[, 3]) < -90){
      warning(paste("Check polygon input coordinates. File contains latitude values outside possible range in row:",
                 rownames(polycord[polycord[,3] < -90,]),"\n", "Coordinates set to minimum: -90 \n", sep = ""))
      polycord[polycord[, 3] < -90,3] <- -90
    }
    poly <- .Cord2Polygon(polycord)
    cat("Done \n")
  }else{
    cat("Reading in polygon coordinates. \n")
    poly <- y
    cat("Done \n")
  }
  
  if (dim(coords)[2] !=  3){
    stop(paste("Wrong input format: \n", 
               "Inputfile for coordinates must be a tab-delimited text file with three columns", sep  = ""))
  }
  if (!is.numeric(coords[, 2]) || !is.numeric(coords[, 3])){
    stop(paste("Wrong input format: \n", 
               "Input point coordinates (columns 2 and 3) must be numeric.", sep  = ""))
  }
  if (!is.character(coords[, 1]) && !is.factor(coords[, 1])){
    warning("Coordinate identifier (column 1) should be a string or a factor.")
  } 
 
  cat("Reading in point coordinates. \n")
  coordi <- coords[, c(2, 3)]
  coordi2 <- as.matrix(coordi)
  cat("Done \n")
  res <- list(identifier = coords[, 1], species_coordinates = coordi, 
              polygons = poly)
  class(res) <- "spgeoIN"
  return(res)
  
}

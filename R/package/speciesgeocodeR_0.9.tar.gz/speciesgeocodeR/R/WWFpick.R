WWFpick <-
function(x, name, scale = c("REALM", "BIOME", "ECOREGION")){
  match.arg(scale)
  if (scale[1] ==  "REALM"){
    indrealm <- cbind(c("Australasia", "Antarctic", 
                        "Afrotropics", "IndoMalay", 
                        "Nearctic", "Neotropics", 
                        "Oceania", "Palearctic"), 
                      c("AA", "AN", "AT", "IM", "NA", "NT", "OC", "PA"))
    if (name[1] ==  "all"){name <- indrealm[, 1]}
    test <- name %in% indrealm
    if (F %in% test){
      err <- name[which(test ==  F)]
      stop(paste("Wrong input value. The following Realms were not found. \n", 
                 "Check spelling. See WWFnam() for a list of available options.\n", err, "\n", sep = ""))
    }
    index <- indrealm[which(indrealm[, 1] %in% name), 2]
    dat <- subset(x, x$REALM %in% index)
  }
  if (scale[1] ==  "BIOME"){
    indbiom <- cbind(c( "Tropical and Subtropical Moist Broadleaf Forests", 
                        "Tropical and Subtropical Dry Broadleaf Forests", 
                        "Tropical and Subtropical Coniferous Forests", 
                        "Temperate Broadleaf and Mixed Forests", 
                        "Temperate Conifer Forests", 
                        "Boreal Forests/Taiga", 
                        "Tropical and Subtropical Grasslands and Savannas and Shrublands", 
                        "Temperate Grasslands and Savannas and Shrublands", 
                        "Flooded Grasslands and Savannas", 
                        "Montane Grasslands and Shrublands", 
                        "Tundra", 
                        "Mediterranean Forests, Woodlands and Scrub", 
                        "Deserts and Xeric Shrublands", 
                        "Mangroves"), c(1:14))
    if (name[1] ==  "all"){name <- indbiom[, 1]}
    test <- name %in% indbiom
    if (F %in% test){
      err <- name[which(test ==  F)]
      stop(paste("Wrong input value. The following Biomes were not found. \n", 
                 "Check spelling. See WWFnam() for a list of available options. \n", err, "\n", sep = ""))
    }
    index <- which(indbiom[, 1] %in% name)
    dat <- subset(x, x$BIOME %in% index)
    
  }
  if (scale[1] ==  "ECOREGION"){
    if (name[1] ==  "all"){name <- levels(x$ECO_NAME)}
    test <- name %in% levels(x$ECO_NAME)
    if (F %in% test){
      err <- name[which(test ==  F)]
      stop(paste("Wrong input value. The following ecoregions were not found. \n", 
                 "Check spelling. See WWFnam() for a list of available options. \n", err, "\n", sep = ""))
    }
    dat <- subset(x, x$ECO_NAME %in%  name)
  }
  return(dat) 
}

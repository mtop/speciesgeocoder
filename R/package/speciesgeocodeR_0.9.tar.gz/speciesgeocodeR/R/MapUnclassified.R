MapUnclassified <-
function(x, moreborders = FALSE, ...){
  if (!class(x) ==  "spgeoOUT"){
    stop("This function is only defined for class spgeoOUT")
  }
  dat <- data.frame(x$not_classified_samples)
  data("wrld_simpl", envir = environment())
  if (dim(dat)[1] ==  0){
    plot(c(1:20), c(1:20), type  = "n", axes = F, xlab = "", ylab = "")
    text(10, 10, labels = paste("All points fell into the polygons and were classified.\n", 
                                "No unclassified points", sep = ""))
  }else{
    xmax <- min(max(dat$XCOOR) + 2, 180)
    xmin <- max(min(dat$XCOOR) - 2, -180)
    ymax <- min(max(dat$YCOOR) + 2, 90)
    ymin <- max(min(dat$YCOOR) - 2, -90)
    
    cat("Creating map of unclassified samples. \n")
    map ("world", xlim = c(xmin, xmax), ylim = c(ymin, ymax), ...)
    axis(1)
    axis(2)
    title("Samples not classified to polygons \n")
    if (moreborders == T) {plot(wrld_simpl, add = T)}
    cat("Adding polygons \n")
    if(class(x$polygons) == "list"){
      plota <- function(x){plot(x, add = T, col = "grey60", border = "grey40")}
      lapply(x$polygons, plota)
    }else{
      plot(x$polygons, col = "grey60", border = "grey40", add = T, ...)
    }
    cat("Adding sample points \n")
    points(dat$XCOOR, dat$YCOOR, 
           cex = 0.5, pch = 3 , col = "red", ...)
    box("plot")
  }
}

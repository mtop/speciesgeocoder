SpGeoCod <-
function(x, y){
  ini <- ReadPoints(x, y)
  outo <- SpGeoCodH(ini)
  return(outo)
}

MapPerSpecies <-
function(x, moreborders = FALSE, plotout = FALSE, ...){
  if (!class(x) ==  "spgeoOUT"){
    stop("This function is only defined for class spgeoOUT")
  }
  data("wrld_simpl", envir = environment())
  layout(matrix(c(1, 1, 1, 1), ncol = 1, nrow = 1))
  if (plotout ==  FALSE){par(ask = T)}
  dat <- data.frame(x$sample_table, x$species_coordinates_in)
  names(dat) <- c("identifier", "homepolygon","XCOOR","YCOOR")
  liste <- levels(dat$identifier)
  
  
  for(i in 1:length(liste)){
    cat(paste("Mapping species: ", i, "/", length(liste), ": ", liste[i], "\n",sep = ""))
    kk <- subset(dat, dat$identifier ==  liste[i])

    inside <- kk[!is.na(kk$homepolygon),]
    outside <- kk[is.na(kk$homepolygon),]
    
    xmax <- min(max(dat$XCOOR) + 2, 180)
    xmin <- max(min(dat$XCOOR) - 2, -180)
    ymax <- min(max(dat$YCOOR) + 2, 90)
    ymin <- max(min(dat$YCOOR) - 2, -90)
    
    map ("world", xlim = c(xmin, xmax), ylim = c(ymin, ymax))
    axis(1)
    axis(2)
    title(liste[i])
    if (moreborders == T) {plot(wrld_simpl, add = T)}
    plot(x$polygons, col = "grey60", add = T)
    
    if(length(inside) > 0){
      points(inside$XCOOR, inside$YCOOR, 
             cex = 0.7, pch = 3 , col = "blue")
    }
    if(length(outside) >0){
      points(outside$XCOOR, outside$YCOOR, 
             cex = 0.7, pch = 3 , col = "red")
    }
    box("plot")
  }
  par(ask = F)
}

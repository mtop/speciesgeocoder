HeatPlotCoEx <-
function(x, ...){
  
  if (class(x) ==  "spgeoOUT" ){
    dat <- x$coexistence_classified
  }else{ 
    dat <- x
  }
  if(dim(dat)[1] > 40) {
    plot(c(1,10),c(1,10), type = "n", axes = F, xlab ="", ylab="")
    text(0,5, 
         label = "The Co-existence plot is only possible with less than 40 species.
         \n See species coexistence matrix for results.",adj = 0)
  }else{
    if (class(dat) !=  "data.frame"){
      stop("Wrong input format. Input must be a data.frame.")
    }
    if (dim(dat)[2] !=  (dim(dat)[1] + 1)){
      warning("Suspicous data dimensions, check input file.")
    }
    ymax <- dim(dat)[1]
    xmax <- dim(dat)[2]
    colo <- rev(heat.colors(10))
    numer <- rev(1:ymax)
  
    layout(matrix(c(rep(1, 9), 2), ncol = 1, nrow = 10))
    par(mar =  c(0, 10, 10, 0))
    plot(0, xlim = c(0, xmax - 1), ylim = c(0, ymax) , type = "n", axes = F, xlab = "", ylab = "", ...)
    for(j in 2:xmax ){
      cat(paste("Ploting coexistence for species ", j, "/", xmax, ": ", colnames(dat)[j],"\n", sep = ""))
      for(i in 1:ymax){
        if (i ==  (j - 1)){
          rect(j - 2, numer[i] - 1 , j - 1, numer[i], col = "black" )
        }else{
          ind <- round(dat[i, j]/10, 0)
          if (ind ==  0) {
            rect(j - 2, numer[i]-1, j - 1, numer[i], col = "white" )
          }else{
            rect(j - 2, numer[i]-1 , j - 1, numer[i], col = colo[ind] )
          }
        }
      }
    }
    axis(side = 3, at = seq(0.5, (xmax - 1.5)), labels = colnames(dat)[-1], las = 2, cex.axis = .7, pos = ymax)
    axis(2, at = seq(0.5, ymax), labels = rev(dat$identifier), las = 2, cex.axis = .7, pos =  0)
    title("Species co-occurrence", line = 9)
  
    par(mar = c(0.5, 10, 0, 0))
    plot(c(1, 59), c(1, 12), type = "n", axes = F, ylab  = "", xlab = "")
    text(c(13, 13), c(10, 7), c("0%", "10%"))
    text(c(20, 20), c(10, 7), c("20%", "30%"))
    text(c(27, 27), c(10, 7), c("40%", "50%"))
    text(c(34, 34), c(10, 7), c("60%", "70%"))
    text(c(41, 41), c(10, 7), c("80%", "90%"))
    text(c(48), 10, "100%")
    rect(c(9, 9, 16, 16, 23, 23, 30, 30, 37, 37, 44), c(rep(c(10.7, 7.7), 5), 10.7), 
         c(11, 11, 18, 18, 25, 25, 32, 32, 39, 39, 46), c(rep(c(8.7, 5.7), 5), 8.7), 
         col = c("white", colo))
    rect(7, 5, 51, 12)
  }
}

DiversityGrid <-
function(x, xlim , ylim){
  res <- 1
  if(xlim[1] * xlim[2] <0){
    xwidth <- abs((xlim[2] + abs(xlim[1])) / res)
  }else{
    xwidth <- abs((abs(xlim[2]) - abs(xlim[1])) / res)
  }
  if(ylim[1] * ylim[2] <0){
    ywidth <- abs((ylim[2] + abs(ylim[1])) / res)
  }else{
    ywidth <- abs((abs(ylim[2]) - abs(ylim[1])) / res)
  }
  dimen <- xwidth * ywidth
  polyy <- data.frame()
  
  cat("Creating grid. \n")
  
  for(j in 0:(ywidth-1)){
    dimen2 <- j * (xwidth) +  (1:(xwidth))
    polyx <- data.frame()
    ylimd <- c(ylim[2] - res * j , ylim[2] - res * (j+1))
    
    for(i in 0:(xwidth-1)){
      poly <- rbind(c(xlim[1] + res * i, ylimd[2]), 
                    c(xlim[1] + res * (i+1), ylimd[2]),
                    c(xlim[1] + res * (i+1), ylimd[1]), 
                    c(xlim[1] + res * i, ylimd[1]),
                    c(xlim[1] + res * i, ylimd[2]))
      
      poly <- data.frame(cbind(as.character(rep(dimen2[i+1],5)),poly))
      polyx <- rbind(polyx,poly)
      #cat(paste(j, i, "\n"))
    }
    polyy <- rbind(polyy,polyx)
  }
  
  names(polyy) <- c("identifier","XCOOR","YCOOR")
  polyy$XCOOR <- as.numeric(as.character(polyy$XCOOR))
  polyy$YCOOR <- as.numeric(as.character(polyy$YCOOR))
  
  cat("Done.\n")
  
  cat("Converting points.\n")
  poly <- .Cord2Polygon(polyy)
  cat("Done.\n")  
  
  if(class(x) == "spgeoOUT"){
    dum <- data.frame(identifier = x$identifier_in, x$species_coordinates_in)
    x <-dum
  }
  
  ini <- ReadPoints(x,poly)
  
  pp <- .PipSamp(ini)
  spsum <- .SpSumH(pp)
  
  pp <- spsum[, -1]
  pp[pp > 0] <- 1
  test <- data.frame((colSums(pp,na.rm = F)))
  test$identifier <- rownames(test)
  
  alle <- data.frame(identifier = unique(polyy$identifier))
  alle <- merge(alle, test, all = T)
  out <- matrix(alle[,2], ncol = xwidth, nrow = ywidth, byrow = T)
  
  
  out <- raster(out, xmn = xlim[1], xmx = xlim[2], ymn = ylim[1], ymx = ylim[2])
  projection(out)<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" 
  return(out)
}

SpeciesGeoCoder <-
function(x, y, coex = F, graphs = T, wwf = F, scale, ...){
  ini <- ReadPoints(x, y)
  
  outo <- SpGeoCodH(ini)

  if(wwf == T){
    
    outo <- Clust(outo, shape = y,scale = scale)
  }
    
  .WriteTablesSpGeo(outo)
  NexusOut(outo,...)
    
  if(graphs == T && wwf == F){
    .OutPlotSpPoly(outo, ...)
    .OutBarChartPoly(outo, ...)
    .OutBarChartSpec(outo, ...)
    .OutMapAll(outo, ...)
    .OutMapPerSpecies(outo, ...)
    .OutMapPerPoly(outo, ...)
  }
  if(graphs == T && wwf == T){
    .OutPlotSpPoly(outo, ...)
    .OutBarChartPoly(outo, ...)
    .OutBarChartSpec(outo, ...)
    .OutMapAll(outo, ...)
    .OutMapPerSpecies(outo, ...)
    .OutMapPerPoly(outo, scale = scale, ...)
  }
  
  if(coex == T)
    {
    outo <- CoExClass(outo)
    .OutHeatCoEx(outo)
    }
}

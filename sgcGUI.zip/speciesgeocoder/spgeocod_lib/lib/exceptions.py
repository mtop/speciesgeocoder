class MissingPolygonFile(Exception):
	"""
	"No such polygon file:" # %s" #% self.filename
	"""
	pass

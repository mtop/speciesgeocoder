#!/usr/bin/env python 
# spgeocoderGUI
# Created by Daniele Silvestro on 24/04/2012 => silvestro.daniele@gmail.com

import sys
import os
import os.path
from Tkinter import * 
import Tkinter 
import platform
from tkMessageBox import *
from tkFileDialog import *


if platform.system() == "Darwin": current_OS="MacOS"
elif platform.system() == "Windows" or platform.system() == "Microsoft": current_OS = 'Windows'
else: current_OS="Linux"

self_path = os.getcwd()
self_path = "%s/speciesgeocoder" % self_path
self_path = os.path.abspath(self_path)

#geocoder_path = """ "%s" """ % (self_path)


def about():
	version="""   SpeciesGeoCoder v. 1.0   """
	message=    "Give some useful infos here. The icon should be replaced with SGCoder icon in gif format"
	global gif
	self_top = Toplevel()
	self_top.title( "About SpeciesGeoCoder" )
	self_top.geometry( "365x270" )
	self_top.minsize(360,285)
	self_top.maxsize(360,285)
	self_top.config(bg='light Grey')
	self_top.grab_set()
	if platform.system() == "Windows" or platform.system() == "Microsoft":
		icon = "%s/icon.ico" % self_path
		self_top.wm_iconbitmap(icon)
		
	a = Canvas(self_top, width = 500, height = 180, bg = "light Grey", relief=FLAT, highlightbackground="light Grey")
	a.pack(expand = NO, fill = NONE, side=TOP)
	gif1 = "%s/icon.gif" % self_path
	gif = PhotoImage(file = gif1)
	a.create_image(180, 90, image = gif)

	b = Frame(self_top)
	b.pack(fill=NONE, expand=NO, side=TOP)
	b.config(bg = "light Grey", relief=FLAT)

	text = Text(b, padx=80, pady=0, height=1)
	text.insert(END, version)
	text.config(highlightthickness=0)                 
	text.pack(side=TOP, expand=NO, fill=NONE)
	text.config(font=('Arial', 15, 'bold'), relief=FLAT, bg='light Grey', fg= 'Black') 
	text.config(state=DISABLED)

	c = Frame(self_top)
	c.pack(fill=X, expand=NO, side=TOP)
	c.config(bg = "light Grey", relief=FLAT)
	text1 = Text(c, padx=50, pady=0, height=2)
	text1.pack(side=TOP, expand=NO, fill=NONE)
	text1.config(highlightthickness=0)                 
	text1.config(font=('Arial', 12), relief=FLAT, bg='light Grey', fg= 'Black') 
	text1.insert(END, message)
	text1.config(state=DISABLED)
	button6 = Tkinter.Button(c, text='open wiki...', padx=15, pady=2, command=online_help, default=ACTIVE)
	button6.pack(side=TOP)
	button6.config(highlightbackground =  "light Grey")
	def close_short(a): self_top.destroy()
	def more_short(a): more()
	self_top.bind("<Return>", online_help)
	self_top.bind("<Command-w>", close_short)	
	self_top.bind("<Control-w>", close_short)	
	self_top.bind("<Escape>", close_short)	

def restart_me():
	if current_OS=='Windows': cmdScript= """ start "raxmlGUI console" /D "%s" dendropy_installer_utility.py""" % self_path
	elif current_OS=='MacOS': cmdScript= """osascript -e 'tell application "Terminal" to do script "cd '%s' && python dendropy_installer_utility.py" '""" % self_path
	else: cmdScript= """xterm -e 'cd "%s" && cd .. && python dendropy_installer_utility.py ' & """ % self_path
	print cmdScript
	os.system(cmdScript)
	self.quit()


def online_help(a=0):
	if current_OS == 'MacOS':
		cmd= "open https://github.com/mtop/speciesgeocoder/wiki" 
		os.system(cmd)
	if current_OS=='Linux':
		cmd= "xdg-open https://github.com/mtop/speciesgeocoder/wiki" 
		os.system(cmd)
	if current_OS=='Windows':
		cmd= "start https://github.com/mtop/speciesgeocoder/wiki"
		os.system(cmd)




def get_file(var,str_title,a_row,a_column,set_out=False): 
	f = askopenfilename(title=str_title) #, parent=self)
	var['textvariable'] = f
	file_name = os.path.basename(f)+100*" "
	name_file = os.path.splitext(file_name)[0]
	Label(self, text=file_name, bg = col).grid(row=a_row,  column=a_column, sticky=W, columnspan=5)
	if set_out==True: outfile.set(name_file+".nex")
	
def get_file_list(var,str_title,a_row,a_column): 
	f = askopenfilenames(title=str_title) #, parent=self)
	f1=list(f)
	var['textvariable'] = f
	if len(f1)>1: num_file= " and %s other file(s)" % (len(f1)-1)
	else: num_file=""
	file_name = os.path.basename(f1[0])+ num_file  +100*" "
	Label(self, text=file_name, bg = col).grid(row=a_row,  column=a_column, sticky=W, columnspan=5)

def get_dir(var,str_title,a_row,a_column): 
	d = askdirectory(title=str_title) #, parent=self)
	var['textvariable'] = d
	file_name = os.path.basename(d)  +100*" "
	Label(self, text=file_name, bg = col).grid(row=a_row,  column=a_column, sticky=W, columnspan=5)
	

def run_a_cmd(cmd_str,print_out=False):
	if cmd_str != None:
		if current_OS == 'Windows':
			runWin = "start /wait"
			winD = "/D"
			winEx = "\n exit" 
			sys_exe= sys.executable
		else:
			runWin = ""
			winD = ""
			winEx = ""
			sys_exe = "python"
		cmd= """cd %s "%s/spgeocod_lib/" && %s geocoder.py %s %s """ \
		% (winD, self_path, sys_exe, cmd_str, winEx)
		if print_out==True: print cmd
		else: 
			os.system(cmd)
			t="""The output nexus file was saved as: "\n\n%s/%s""" % (os.path.dirname(str(B_loc_file['textvariable'])),outfile.get())
			showinfo("Analysis completed", t, parent=self) 
	

def get_str_cmds(test=False,print_out=False):
	#path_out = "%s/" % os.path.dirname(locality_file) # path input file used for output
	locality_file = str(B_loc_file['textvariable'])
	polygons_file = str(B_pol_file['textvariable'])
	geotif_file   = str(B_tif_file['textvariable'])	
	out_file      = "%s/%s" % (os.path.dirname(locality_file),outfile.get())
	print plot_res.get()
	try:
		for arg in [locality_file,polygons_file,geotif_file]:
			if arg=="": raise(NameError)
		str_cmd= "-l %s -p %s -t %s > %s " % (locality_file,polygons_file,geotif_file,out_file)
		if test==True: str_cmd += " --test"
		if plot_res.get()==1: str_cmd += " --plot"
		return str_cmd
	except(NameError): showinfo("Warning", "Input file missing!", parent=self) 

#def clear_label(widg=):
#	widg.destroy()

### MAIN TOOLBAR
self = Tk()
self.geometry("665x100")
self.title( "SpeciesGeoCoder - GUI" )
col = "#DBDBDB"
self.config(bg=col)
self.minsize(365,150)
self.tk.call('after','idle','console','hide')

Label(self, text=' ', bg = col).grid(row=1,  column=1, sticky=W)
#filez = askopenfilenames(parent=self,title='Choose a file')
#print self.tk.splitlist(filez)

Label(self, text="<Choose a file>",      bg = col).grid(row=1,  column=4, sticky=W)
Label(self, text="<Choose a file>",      bg = col).grid(row=2,  column=4, sticky=W)
Label(self, text="<Choose a directory>", bg = col).grid(row=3,  column=4, sticky=W)

self.grab_set()	
B_loc_file = Button(self) # 
B_loc_file.grid(row=1,  column=2, sticky=W, columnspan=2)	
B_loc_file.config(highlightbackground = col, text='Locality data',command= lambda: get_file(B_loc_file,"Select locality data file",1,4,set_out=True))

B_pol_file = Button(self) # 
B_pol_file.grid(row=2,  column=2, sticky=W, columnspan=2)
B_pol_file.config(highlightbackground = col, text='Polygon file', command= lambda: get_file(B_pol_file,"Select polygon file",2,4))
#
B_tif_file = Button(self) # 
B_tif_file.grid(row=3,  column=2, sticky=W, columnspan=2)	
B_tif_file.config(highlightbackground = col, text='Geotif file', command= lambda: get_dir(B_tif_file,"Select geotif directory",3,4)) #get_file_list(B_tif_file,"Select one or more geotif files",3,2))


entry = Entry(width = 20)
outfile = StringVar()
entry["textvariable"] = outfile
entry.grid(row=4,  column=2, sticky=W, columnspan=2)
if current_OS == 'MacOS':	entry.config(font=(11), bg='white', fg= 'dark blue', highlightthickness=0)  
else:	entry.config(bg='white', fg= 'dark blue', highlightthickness=0)  
entry.focus_set()
outfile.set('outfile')

plot_res = StringVar()
check1k = Checkbutton(self, text="Plot results", variable=plot_res, onvalue=True, offvalue=False)
check1k.grid(row=4,  column=4, sticky=W)
check1k.config(bg = col)
check1k.deselect()

B_check = Button(self) # Load alignment
B_check.grid(row=5,  column=2, sticky=W, columnspan=1)	
B_check.config(highlightbackground = col, text='Check input files', command= lambda: run_a_cmd(get_str_cmds(test=True),print_out=True))

B_run = Button(self) # Load alignment
B_run.grid(row=5,  column=3, sticky=W, columnspan=1)	
B_run.config(highlightbackground = col, text='Run', command= lambda: run_a_cmd(get_str_cmds()))

B_print_cmd = Button(self) # Load alignment
B_print_cmd.grid(row=5,  column=4, sticky=W, columnspan=1)	
B_print_cmd.config(highlightbackground = col, text='print cmd', command= lambda: run_a_cmd(get_str_cmds(),print_out=True))


B_help = Button(self) # Load alignment
B_help.grid(row=5,  column=5, sticky=W, columnspan=5)	
B_help.config(highlightbackground = col, text='Help', command=about) 

self.option_add('*tearOff', FALSE)
menu = Menu(self)
self.config(menu=menu)



## RUN SGC
self.mainloop()
